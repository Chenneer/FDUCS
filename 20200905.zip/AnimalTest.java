public class AnimalTest{
    public static void main(String[] args){
        Animal a = new Animal();//Animal 对象
        Dog d = new Dog();//Dog对象
        Animal b = new Dog();//Dog 对象,向上转型为Animal类型
        a.bark();//执行Animal类的方法
        d.bark();//执行Dog类的方法
        b.bark();//执行Dog类的方法
    }
}