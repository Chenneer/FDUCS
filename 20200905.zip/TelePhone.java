//抽象方法
public abstract class TelePhone{
    public abstract void call();//抽象方法，打电话
    public abstract void message();//抽象方法 发短信
}